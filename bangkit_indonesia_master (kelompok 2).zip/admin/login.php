<?php
include '_config.php';
session_start();
if(isset($_SESSION["user"])) header("Location: index.php");
if(isset($_POST['login'])){
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
$sql = "SELECT * FROM user WHERE username=:username OR password=:password";
$stmt = $db->prepare($sql);
$params = array(
":username" => $username,
":password" => $password
);
$stmt->execute($params);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if($user){
if($password == $user["password"]){
$_SESSION["user"] = $user;
header("Location: index.php");
}else if($password != $user["password"]) { ?>
<script>
alert('Password salah!')
location.href = 'login.php'
</script>
<?php
}
}

else if(!$user) { ?>
<script>
alert('Username tidak ditemukan!')
location.href = 'login.php'
</script>
<?php
}
}
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/cs
s/bootstrap.min.css" integrity="sha384-
Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossor igin="anonymous">
<style>
    body {
        background: url(assets/bela.jpg) no-repeat;
        background-size: cover;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        flex-direction: column;
    }

    form {
        width: 500px;
        border: 2px solid #ccc;
        padding: 30px;
        background: #fff;
        border-radius: 15px;
    }

    h2 {
        text-align: center;
        margin-bottom: 40px;
    }

    input {
        display: block;
        border: 2px solid #ccc;
        width: 95%;
        padding: 10px;
        margin: 10px auto;
        border-radius: 5px;
    }

    label {
        color: #888;
        font-size: 18px;
        padding: 10px;
    }

    button {
        float: right;
        padding: 10px 15px;
        border-radius: 5px;
        margin-right: 10px;
        border: none;
    }

    .error {
        background: #F2DEDE;
        color: #A94442;
        padding: 10px;
        width: 95%;
        border-radius: 5px;
        margin: 20px auto;
    }
</style>

</head>
<body class="bg-light">
<div class="container mt-5">
<div class="row">
<div class="col-md-6">

<form action="" method="POST">
<div class="form-group">
<label for="username">Username</label>
<input class="form-control" type="text" name="username" placeholder="Username" />
</div>
<div class="form-group">
<label for="password">Password</label>
<input class="form-control" type="password" name="password" placeholder="Password"
/>
</div>
<input type="submit" class="btn btn-success btn-block" name="login" value="Masuk" />
<h3 align="center" style="text-decoration"><a href="/bangkit_indonesia-master/">Kembali Ke Halaman Web utama</h2>
</form>
</div>
</div>
</div>
</body>