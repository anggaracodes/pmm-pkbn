<?php
error_reporting(0);
include '_config.php';
require_once("autintifikasi.php");
$id = $_POST['id'];
$keterangan = $_POST['keterangan'];
$gambar = $_POST['gambar'];
$id_user = $_SESSION["user"]["id_user"];
$namafile = $_FILES['gambar']['name'];
$tmp_name = $_FILES['gambar']['tmp_name'];
move_uploaded_file($tmp_name, 'img_gallery/' . $namafile);
if($namafile == '') {
$update = mysqli_query($con, "UPDATE gallery SET id_user='$id_user' , keterangan='$keterangan'
WHERE id ='$id'");
}else {
$update = mysqli_query($con, "UPDATE gallery SET gambar ='$namafile', id_user='$id_user' ,
keterangan='$keterangan' WHERE id ='$id'");}
if ($update) { ?>
<script>
alert('Data berhasil diubah!')
location.href = 'page_galerry.php'
</script> <?php
} else { ?>
<script>
alert('Data Gagal diubah!')
location.href = 'page_galerry.php'
</script> <?php } ?>