<div class="card im-box">
    <h5 class="card-header">Selamat Datang</h5>
    <div class="card-body">
        <h5 class="card-title">Simple CRUD PHP Native dengan Tema Bela Negara</h5>
        <p class="card-text">Kita tidak boleh berhenti berkreasi, berinovasi, dan berprestasi. Kita harus buktikan ketangguhan kita. Kita harus menangkan masa depan kita dan kita wujudkan cita-cita para Pendiri Bangsa dengan semangat bela negara,</p>
        <a href="page_about.php" class="btn btn-primary">Learn More</a>
    </div>
</div>